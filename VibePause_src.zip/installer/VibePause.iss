#define MyAppName "VibePause"
#define MyAppPublisher "tanveer-exe"
#define MyAppExeName "VibePause.exe"

[Setup]
AppId={{D5B8B6B7-7B61-4D1D-9D73-3A1B9A0D1E42}
AppName={#MyAppName}
AppVersion=0.1.3
AppPublisher={#MyAppPublisher}
DefaultDirName={userdocs}\VibePause
DefaultGroupName=VibePause
DisableProgramGroupPage=yes
DisableDirPage=no
PrivilegesRequired=lowest
OutputDir=..\installer_output
OutputBaseFilename=VibePause_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardImageFile=wizard_large.bmp
WizardSmallImageFile=wizard_small.bmp
SetupIconFile=..\VibePause.ico
UninstallDisplayIcon={app}\VibePause.ico
UninstallDisplayName=VibePause
ArchitecturesInstallIn64BitMode=x64compatible
AppMutex=VibePauseSingleInstanceMutex
CloseApplications=yes
RestartApplications=no
Uninstallable=yes

[Code]
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
  OldInstalled: Boolean;
  OldVersion: String;
begin
  Result := True;

  // Check if VibePause is already installed
  OldInstalled := RegKeyExists(HKLM, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1') or
                  RegKeyExists(HKLM, 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1');

  if OldInstalled then
  begin
    // Get the old version
    if RegValExists(HKLM, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'DisplayVersion') then
      RegQueryStringValue(HKLM, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'DisplayVersion', OldVersion)
    else if RegValExists(HKLM, 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'DisplayVersion') then
      RegQueryStringValue(HKLM, 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'DisplayVersion', OldVersion);

    // Ask user what they want to do
    case MsgBox('VibePause ' + OldVersion + ' is already installed.' + #13#13 +
                'What would you like to do?' + #13#13 +
                '1. Repair existing installation' + #13 +
                '2. Update to version ' + '{#SetupSetting("AppVersion")}' + #13 +
                '3. Remove existing installation first', mbCustomMsgBox, MB_YESNOCANCEL, _
                'Repair', 'Update', 'Remove') of
      IDYES:  // Repair
        begin
          // Continue with installation (will repair over existing)
          Result := True;
        end;
      IDNO:   // Update
        begin
          // Continue with installation (will update)
          Result := True;
        end;
      IDCANCEL: // Remove
        begin
          // First uninstall the old version
          if UninstallOldVersion() then
          begin
            // Continue with fresh installation
            Result := True;
          end
          else
          begin
            // Abort if uninstall failed
            Result := False;
          end;
        end;
    end;
  end;
end;

function UninstallOldVersion(): Boolean;
var
  UninstallString: String;
  ResultCode: Integer;
begin
  Result := False;

  // Get the uninstall string from registry
  if RegValExists(HKLM, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'UninstallString') then
    RegQueryStringValue(HKLM, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'UninstallString', UninstallString)
  else if RegValExists(HKLM, 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'UninstallString') then
    RegQueryStringValue(HKLM, 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\VibePause_is1', 'UninstallString', UninstallString);

  if UninstallString <> '' then
  begin
    // Silent uninstall of existing version
    if Exec(ExpandConstant(UninstallString), '/SILENT', '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
    begin
      Result := (ResultCode = 0);
    end;
  end;
end;

[Files]
Source: "..\dist\VibePause\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\VibePause.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\VibePause"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\VibePause.ico"; AppUserModelID: "tanveer-exe.VibePause"
Name: "{autodesktop}\VibePause"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\VibePause.ico"; Tasks: desktopicon; AppUserModelID: "tanveer-exe.VibePause"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Registry]
; Remove the Run-on-Startup entry when VibePause is uninstalled.
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueName: "VibePause"; Flags: uninsdeletevalue dontcreatekey

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch VibePause"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Preserve the user's config in Documents\VibePause
; Only remove the old AppData location if it exists (for cleanup)
Type: filesandordirs; Name: "{localappdata}\VibePause"; Flags: ignoresversion
