#define MyAppName "VibePause"
#define MyAppPublisher "tanveer-exe"
#define MyAppExeName "VibePause.exe"

[Setup]
AppId={{D5B8B6B7-7B61-4D1D-9D73-3A1B9A0D1E42}
AppName={#MyAppName}
AppVersion=0.1.1
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\VibePause
DefaultGroupName=VibePause
DisableProgramGroupPage=yes
DisableDirPage=yes
PrivilegesRequired=lowest
OutputDir=..\installer_output
OutputBaseFilename=VibePause_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardImageFile=wizard_large.bmp
WizardSmallImageFile=wizard_small.bmp
SetupIconFile=..\VibePause.ico
UninstallDisplayIcon={app}\VibePause.ico
UninstallDisplayName=VibePause
ArchitecturesInstallIn64BitMode=x64compatible
AppMutex=VibePauseSingleInstanceMutex
CloseApplications=yes
RestartApplications=no

[Files]
Source: "..\dist\VibePause\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\VibePause.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\VibePause"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\VibePause.ico"; AppUserModelID: "tanveer-exe.VibePause"
Name: "{autodesktop}\VibePause"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\VibePause.ico"; Tasks: desktopicon; AppUserModelID: "tanveer-exe.VibePause"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Registry]
; Remove the Run-on-Startup entry when VibePause is uninstalled.
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueName: "VibePause"; Flags: uninsdeletevalue dontcreatekey

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch VibePause"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{userappdata}\VibePause"
