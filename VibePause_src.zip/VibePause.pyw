import os, sys, re, time, ctypes, threading, queue, json, winreg, math, urllib.request, urllib.error, tempfile, subprocess
from pathlib import Path
import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont
from tkinter import messagebox

try:
    import pystray
    from PIL import Image, ImageDraw, ImageTk
    TRAY_AVAILABLE = True
except Exception:
    TRAY_AVAILABLE = False

APP_NAME = "VibePause"
APP_ID = "tanveer-exe.VibePause"
APP_VERSION = "0.1.3"
UPDATE_REPO = "Tanveer-exe/VibePause"
UPDATE_ASSET = "VibePause_Setup.exe"
# Bundled resources: PyInstaller extracts/places them under sys._MEIPASS.
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
APPDATA = Path(os.getenv("USERPROFILE", str(Path.home()))) / "Documents" / "VibePause"
LEGACY_APPDATA = Path(os.getenv("APPDATA", str(Path.home()))) / "VibePause"
CONFIG = APPDATA / "settings.json"
LEGACY_CONFIG = LEGACY_APPDATA / "settings.json"
LOG = Path(os.environ.get("LOCALAPPDATA", "")) / "VALORANT" / "Saved" / "Logs" / "ShooterGame.log"
STARTUP_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
STARTUP_NAME = "VibePause"
VK_MEDIA_PLAY_PAUSE = 0xB3
KEYUP = 0x0002
user32 = ctypes.windll.user32

# Give Windows a stable AppUserModelID so the taskbar uses VibePause's
# application identity and icon instead of a generic Tk/Python icon.
if os.name == "nt":
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p(APP_ID))
    except Exception:
        pass

# Update checking constants
UPDATE_CHECK_INTERVAL = 4 * 60 * 60  # 4 hours in seconds
UPDATE_CHECK_TIMEOUT = 12  # seconds for GitHub API request

# Legal acceptance constants
LEGAL_ACCEPTANCE_KEY = "legal_accepted_v" + APP_VERSION.replace(".", "_")
LEGAL_FILES = ["TERMS_AND_CONDITIONS.md", "PRIVACY_POLICY.md"]

EVENTS = [
    ("Combat Start", "A round becomes active"),
    ("Player Eliminated", "The local player dies during a round"),
    ("Match Started", "The match becomes active"),
    ("Buy Phase Started", "The buy phase opens"),
    ("Match Ended", "The match ends"),
    ("Returned to Lobby", "You return to the main menu"),
    ("Agent Selection", "Agent selection opens"),
    ("Ultimate Used", "The player is resurrected with ultimate"),
]
DEFAULT_ACTIONS = {
    "Combat Start": "Pause",
    "Player Eliminated": "Play",
    "Match Started": "Play",
    "Buy Phase Started": "Play",
    "Match Ended": "Play",
    "Returned to Lobby": "Play",
    "Agent Selection": "Play",
    "Ultimate Used": "Play",
}

# These are the four apps intentionally shown in the UI.
MEDIA_APPS = ["Google Chrome", "YouTube Music", "Apple Music", "Spotify"]

# ---------------------------------------------------------------------------
# Updater logic (pure functions, no UI). Outcomes are explicit so "no update"
# is never reported as a failure.
# ---------------------------------------------------------------------------
UPDATE_API = f"https://api.github.com/repos/{UPDATE_REPO}/releases?per_page=20"

class UpdateError(Exception):
    """A real problem (network, GitHub, missing installer) with a message safe to show the user."""

def version_tuple(value):
    """'v0.1.1' -> (0, 1, 1). Ignores a leading v and any suffix such as '-alpha'."""
    m = re.match(r"^\s*[vV]?(\d+(?:\.\d+)*)", str(value or ""))
    if not m:
        return None
    parts = [int(x) for x in m.group(1).split(".")]
    while len(parts) > 1 and parts[-1] == 0:   # 0.1.0 == 0.1
        parts.pop()
    return tuple(parts)

def pick_update(releases, current_version, asset_name=UPDATE_ASSET):
    """Decide what to do from a GitHub /releases list.

    Returns ("current", latest_version_str)
         or ("update", latest_version_str, download_url, size)
    Raises UpdateError if a newer release exists but has no installer.
    Pre-releases are included (the project publishes alpha releases); drafts are not.
    """
    cur = version_tuple(current_version) or (0,)
    best, best_v = None, None
    for rel in releases or []:
        if rel.get("draft"):
            continue
        v = version_tuple(rel.get("tag_name"))
        if v is None:
            continue
        if best_v is None or v > best_v:
            best, best_v = rel, v
    if best is None:
        return ("current", str(current_version))     # nothing published yet -> nothing newer
    latest = str(best.get("tag_name", "")).lstrip("vV")
    if best_v <= cur:
        return ("current", latest)
    for asset in best.get("assets", []) or []:
        if asset.get("name") == asset_name and asset.get("browser_download_url"):
            return ("update", latest, asset["browser_download_url"], int(asset.get("size") or 0))
    raise UpdateError(f"VibePause {latest} was published, but its installer ({asset_name}) is missing from the release.")

def fetch_releases(timeout=UPDATE_CHECK_TIMEOUT):
    """Download the release list from GitHub with friendly errors."""
    req = urllib.request.Request(UPDATE_API, headers={
        "User-Agent": f"VibePause/{APP_VERSION}", "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise UpdateError("GitHub returned 404 for the VibePause releases. The repository must be public for updates to work.")
        if e.code in (403, 429):
            raise UpdateError("GitHub is rate-limiting update checks right now. Try again in a few minutes.")
        raise UpdateError(f"GitHub returned an error (HTTP {e.code}). Try again later.")
    except urllib.error.URLError as e:
        raise UpdateError(f"Could not reach GitHub. Check your internet connection. ({e.reason})")
    except (TimeoutError, OSError) as e:
        raise UpdateError(f"Could not reach GitHub ({type(e).__name__}). Check your internet connection.")
    except ValueError:
        raise UpdateError("GitHub sent a reply VibePause could not read.")
    if not isinstance(data, list):
        raise UpdateError("Unexpected reply from GitHub.")
    return data


try:
    import asyncio
    from winrt.windows.media.control import (
        GlobalSystemMediaTransportControlsSessionManager as _SessionManager,
        GlobalSystemMediaTransportControlsSessionPlaybackStatus as _PlaybackStatus,
    )
    GSMTC_AVAILABLE = True
except Exception:
    GSMTC_AVAILABLE = False

async def _gsmtc_set(desired, selected_app="Any"):
    """Explicitly play/pause a real music session.

    VALORANT can coexist with several Windows media sessions.  Using only
    get_current_session() is unreliable because the foreground/current
    session is not necessarily the music player.  Prefer one of the media
    apps VibePause supports, then fall back to the current session.
    """
    mgr = await _SessionManager.request_async()
    sessions = list(mgr.get_sessions())

    def is_music_session(session):
        try:
            sid = (session.source_app_user_model_id or "").lower()
        except Exception:
            sid = ""
        # Chrome covers YouTube Music in a browser.  Keep the matching broad
        # enough for the Store/desktop variants of the supported players.
        return any(x in sid for x in (
            "chrome", "spotify", "applemusic", "apple.music",
            "music.apple", "youtube"
        ))

    def is_specific_app_session(session, app_name):
        try:
            sid = (session.source_app_user_model_id or "").lower()
        except Exception:
            sid = ""

        # Map app names to their identifiers in session source_app_user_model_id
        app_map = {
            "Google Chrome": ["chrome"],
            "YouTube Music": ["youtube"],  # YouTube Music in Chrome
            "Apple Music": ["applemusic", "apple.music", "music.apple"],
            "Spotify": ["spotify"]
        }

        if app_name not in app_map:
            return False

        return any(x in sid for x in app_map[app_name])

    session = None

    if selected_app == "Any":
        # Original behavior: look for any supported app, then fall back to current session
        session = next((x for x in sessions if is_music_session(x)), None)
        if session is None:
            session = mgr.get_current_session()
    else:
        # Look for the specific selected app
        session = next((x for x in sessions if is_specific_app_session(x, selected_app)), None)
        # If specific app not found, don't fall back to current session - return None to indicate failure

    if session is None:
        return None

    info = session.get_playback_info()
    playing = info.playback_status == _PlaybackStatus.PLAYING

    if desired and not playing:
        await session.try_play_async()
    elif not desired and playing:
        await session.try_pause_async()

    return desired

class Controller:
    def __init__(self, ui):
        self.ui = ui
        self.stop_event = threading.Event()
        self.thread = None
        self.music_playing = True
        self.current_event = "Return to Lobby"
        self.in_match = False
        self.game_started = False
        self.character_select_seen = False
        self.round_active = False
        self.round_started_at = 0.0
        self.last_event = None
        self.last_event_time = 0.0
        self.lock = threading.Lock()

    def toggle_media(self):
        user32.keybd_event(VK_MEDIA_PLAY_PAUSE, 0, 0, 0)
        user32.keybd_event(VK_MEDIA_PLAY_PAUSE, 0, KEYUP, 0)

    def set_playing(self, desired):
        """Make the media session playing (True) or paused (False). Never blind-toggles when it can read the real state."""
        with self.lock:
            if GSMTC_AVAILABLE:
                try:
                    # Get the currently selected media app from UI
                    selected_app = self.ui.selected_media_app.get()
                    result = asyncio.run(_gsmtc_set(desired, selected_app))
                    if result is None:
                        if selected_app == "Any":
                            self.ui.event("system", "No active Windows media session")
                        else:
                            self.ui.event("system", f"No active session found for {selected_app}")
                        return False
                    self.music_playing = desired
                    return True
                except Exception as e:
                    self.ui.event("system", f"Media session error: {e}")
            # Fallback (media session API unavailable): old toggle behaviour based on tracked state.
            if desired != self.music_playing:
                self.toggle_media()
                self.music_playing = desired
            return True

    def apply_action(self, event, actions, delay):
        # Do not apply actions if VibePause is inactive
        if not self.ui.active:
            return

        # VALORANT can emit the same state/menu line more than once.  Do not
        # repeatedly send Play/Pause for the same event within a short window.
        now = time.monotonic()
        if event == self.last_event and (now - self.last_event_time) < 0.75:
            return
        self.last_event = event
        self.last_event_time = now

        action = actions.get(event, "None")
        self.current_event = event
        self.ui.event("event", (event, action))
        if action == "None":
            return
        if delay:
            time.sleep(delay / 1000)
        desired = action == "Play"
        if self.set_playing(desired):
            self.ui.event("music", "Playing" if desired else "Paused")

    def follow(self):
        while not self.stop_event.is_set():
            try:
                f = open(LOG, "r", encoding="utf-8", errors="ignore")
                f.seek(0, os.SEEK_END)
                self.ui.event("system", "Monitoring Valorant...")
                return f
            except FileNotFoundError:
                self.ui.event("system", "Waiting for Valorant...")
                time.sleep(1.5)
        return None

    def start(self, actions, delay):
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self.run, args=(actions, delay), daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def run(self, actions, delay):
        f = self.follow()
        if not f:
            return

        # Starting VibePause while VALORANT is already open should begin from
        # a known safe state.  From here on, only fresh log lines are used.
        self.in_match = False
        self.game_started = False
        self.character_select_seen = False
        self.round_active = False
        self.round_started_at = 0.0
        self.apply_action("Return to Lobby", actions, 0)

        while not self.stop_event.is_set():
            line = f.readline()
            if not line:
                try:
                    # VALORANT can rotate/truncate ShooterGame.log. Re-open it
                    # when that happens so monitoring never silently stops.
                    if not LOG.exists() or LOG.stat().st_size < f.tell():
                        f.close()
                        f = self.follow()
                        if not f:
                            return
                except OSError:
                    pass
                time.sleep(.08)
                continue

            line = line.strip()
            low = line.lower()

            # --------------------------------------------------------------
            # High-confidence game-flow state changes from this log version.
            # --------------------------------------------------------------

            # --------------------------------------------------------------
            # Robust VALORANT game-flow detection.
            # A match can go directly from PostMatch/Pregame into another
            # match without returning to MainMenu, so reset match state from
            # both lobby AND post-match/pregame transitions.
            # --------------------------------------------------------------

            # Main menu / lobby. This is the cleanest full reset.
            if ("reconcile called with state: transitiontomainmenu and new state: mainmenu" in low
                    or "reconcile called with the current state: mainmenu" in low
                    or "broadcasting state changed to mainmenu" in low):
                was_in_match = self.in_match or self.game_started
                self.in_match = False
                self.game_started = False
                self.character_select_seen = False
                self.round_active = False
                self.round_started_at = 0.0
                if was_in_match:
                    self.apply_action("Match Ended", actions, delay)
                self.apply_action("Returned to Lobby", actions, delay)
                continue

            # Post-match is also a hard reset. This is important when the
            # player queues another match without a MainMenu transition.
            if any(x in low for x in (
                "waitingtopostmatch", "postmatch", "postgame",
                "transitiontopostmatch", "transitioning from ingame to postmatch"
            )):
                was_in_match = self.in_match or self.game_started
                self.in_match = False
                self.game_started = False
                self.character_select_seen = False
                self.round_active = False
                self.round_started_at = 0.0
                if was_in_match:
                    self.apply_action("Match Ended", actions, delay)
                continue

            # Character select / pregame starts a NEW match lifecycle. Reset
            # game_started here even if VALORANT skipped MainMenu after the
            # previous match.
            if ("characterselectpersistentlevel" in low
                    or "reconcile called with state: transitiontopregame and new state: pregame" in low
                    or "broadcasting state changed to pregame" in low):
                if not self.character_select_seen:
                    self.in_match = True
                    self.game_started = False
                    self.round_active = False
                    self.round_started_at = 0.0
                    self.character_select_seen = True
                    self.apply_action("Agent Selection", actions, delay)
                continue

            # The actual match becomes InGame after loading. Support several
            # equivalent log lines because Riot changes the surrounding text
            # between game versions.
            if ("reconcile called with state: transitiontoingame and new state: ingame" in low
                    or "transitioning from transitiontoingame to ingame" in low
                    or "broadcasting state changed to ingame" in low
                    or "reconcile called with the current state: ingame" in low):
                self.in_match = True
                if not self.game_started:
                    self.game_started = True
                    self.apply_action("Match Started", actions, delay)
                continue

            # Buy/shop phase. This can happen in later rounds too.
            if "opening wbp_screen_preroundshopcontainer_c" in low:
                self.in_match = True
                self.apply_action("Buy Phase Started", actions, delay)
                continue

            # Round/combat starts. If the game-start transition was missed,
            # recover the match state here instead of silently ignoring the
            # combat event.
            if "logshootergamestate" in low and "gameplay started at local time" in low:
                if not self.game_started:
                    self.in_match = True
                    self.game_started = True
                    self.apply_action("Match Begins", actions, delay)
                self.round_active = True
                self.round_started_at = time.monotonic()
                self.apply_action("Combat Start", actions, delay)
                continue

            # Explicit round end is NOT game finish. The next round will emit
            # another Gameplay-started line.
            if any(x in low for x in (
                "ashootergamestate::onroundended",
                "logshootergamestate: onroundended",
                "onroundended"
            )):
                self.round_active = False
                continue

            # Death detection. Recent VALORANT logs can expose the local
            # player's state through `player=Me alive=0`. We only accept it
            # while a combat round is active and after a short grace period
            # following round start, because the same reconnect/spectate
            # marker can appear during initial map loading.
            if (self.in_match and self.round_active
                    and (time.monotonic() - self.round_started_at) >= 2.0
                    and "player=me alive=0" in low):
                self.round_active = False
                self.apply_action("Player Eliminated", actions, delay)
                continue

            # Revive/resurrection. Keep this deliberately narrow.
            if self.in_match and any(x in low for x in (
                "buff_resurrect_oneframedurationinvincible_c",
                "resurrected",
                "resurrection"
            )):
                self.apply_action("Ultimate Used", actions, delay)
                continue

class ImgCheck(tk.Frame):
    """Tick box drawn from image assets (no native checkbox glyphs)."""
    def __init__(self, parent, text, variable, command, imgs, bg, fg, font):
        super().__init__(parent, bg=bg, cursor="hand2")
        self.var, self.command, self.imgs = variable, command, imgs
        self.icon = tk.Label(self, bg=bg, image=imgs[bool(variable.get())], bd=0)
        self.icon.pack(side="left")
        self.lbl = tk.Label(self, text=text, bg=bg, fg=fg, font=font, bd=0)
        self.lbl.pack(side="left", padx=(7, 0))
        for w in (self, self.icon, self.lbl):
            w.bind("<Button-1>", self._click)
        variable.trace_add("write", lambda *a: self.icon.config(image=self.imgs[bool(self.var.get())]))

    def _click(self, _e):
        self.var.set(not self.var.get())
        if self.command:
            self.command()

class App:
    # Valorant-inspired palette: deep navy, off-white, signature red, teal for "play".
    BG = "#0b121a"
    TOP = "#0f1923"
    PANEL = "#111b26"
    PANEL2 = "#182431"
    PANEL3 = "#223142"
    TEXT = "#ece8e1"
    MUTED = "#8b97a5"
    RED = "#ff4655"
    DRED = "#bd3944"
    GREEN = "#3ddbc4"
    BLUE = "#64a9ff"
    BORDER = "#243344"

    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.WIN_W, self.WIN_H = 1040, 680
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.geometry(f"{self.WIN_W}x{self.WIN_H}+{max(0,(sw-self.WIN_W)//2)}+{max(0,(sh-self.WIN_H)//2-20)}")
        self.root.resizable(False, False)
        self.root.configure(bg=self.BG, bd=0, highlightthickness=0)
        self.root.option_add("*Button.highlightThickness", 0)   # no focus outlines on flat buttons
        self.asset_dir = RESOURCE_DIR / "assets"
        self.icon_path = RESOURCE_DIR / "VibePause.ico"
        self._window_icon = None
        try:
            # Keep a Tk icon reference as a fallback for the title bar/taskbar.
            icon_png = self.asset_dir / "vibepause_logo_32.png"
            if icon_png.exists() and TRAY_AVAILABLE:
                self._window_icon = ImageTk.PhotoImage(Image.open(icon_png).convert("RGBA"))
                self.root.iconphoto(True, self._window_icon)
            self.root.iconbitmap(default=str(self.icon_path))
        except Exception:
            pass
        fams = set(tkfont.families(self.root))
        self.fam = "Bahnschrift" if "Bahnschrift" in fams else "Segoe UI"   # DIN-style face ships with Windows 10/11
        self.assets = {}
        self.load_assets()

        self.q = queue.Queue()
        self.actions = DEFAULT_ACTIONS.copy()
        self.action_vars = {}
        self.action_button = {}
        self.action_stripe = {}
        self.delay = 0
        self.running = False
        self.startup = False
        self.close_to_tray = True
        self.settings_open = False
        self.tray_icon = None
        self.drag_x = 0
        self.drag_y = 0
        self._drag_hwnd = None
        self.selected_media_app = tk.StringVar(value="Any")  # For app selection
        # Auto-update / active state: must exist before build() draws the title bar
        self.auto_update_enabled = True
        self.auto_update_timer = None
        self.last_update_check = 0
        self.active = True  # VibePause is active by default
        self.load_auto_update_settings()
        self.load()
        self.controller = Controller(self)
        self.build()
        self.apply_windows_app_style()
        self.root.after(80, self.process)
        self.root.protocol("WM_DELETE_WINDOW", self.on_window_close)
        self.create_tray()
        self.start_quit_listener()
        # Start monitoring based on active state (default: active)
        self.root.after(100, self.start_monitoring)
        if "--startup" in sys.argv and TRAY_AVAILABLE:
            self.root.withdraw()   # launched by Windows at sign-in: start in the tray

        if self.auto_update_enabled:
            self.start_auto_update_checker()

        # Legal acceptance functionality
        self.check_legal_acceptance_on_startup()

    def F(self, size, bold=False):
        return (self.fam, size, "bold" if bold else "normal")

    def load(self):
        try:
            APPDATA.mkdir(parents=True, exist_ok=True)

            # Migrate settings from old location to new location if needed
            if LEGACY_CONFIG.exists() and not CONFIG.exists():
                try:
                    legacy_data = json.loads(LEGACY_CONFIG.read_text(encoding="utf-8"))
                    CONFIG.write_text(json.dumps(legacy_data, indent=2), encoding="utf-8")
                except Exception:
                    pass  # If migration fails, continue with empty settings

            # Load settings from current location
            if CONFIG.exists():
                d = json.loads(CONFIG.read_text(encoding="utf-8"))
                for k in self.actions:
                    val = d.get("actions", {}).get(k)
                    if val in ("Play", "Pause", "None"):
                        self.actions[k] = val
                self.delay = int(d.get("delay", 0))
                self.startup = bool(d.get("startup", False))
                self.close_to_tray = bool(d.get("close_to_tray", True))
                self.selected_media_app.set(d.get("selected_media_app", "Any"))

                # Handle legacy startup key migration
                if "legacy_startup_migrated" not in d:
                    # Try to read startup setting from registry and migrate to config
                    try:
                        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY, 0, winreg.KEY_READ)
                        value, _ = winreg.QueryValueEx(key, STARTUP_NAME)
                        winreg.CloseKey(key)
                        # If we found a startup setting, sync it with config
                        if self.startup:  # Only update if not already set from config
                            pass  # Startup setting will be handled by save() when needed
                    except FileNotFoundError:
                        pass  # No legacy startup setting
                    except Exception:
                        pass
                    # Mark that we've checked for legacy startup
                    d["legacy_startup_migrated"] = True
                    CONFIG.write_text(json.dumps(d, indent=2), encoding="utf-8")
        except Exception:
            pass

    def save(self):
        APPDATA.mkdir(parents=True, exist_ok=True)
        # Merge into the existing file instead of replacing it. Keys this method
        # does not own (legal acceptance, migration flags) must survive every
        # save, otherwise the legal popup comes back on each launch.
        data = {}
        try:
            if CONFIG.exists():
                loaded = json.loads(CONFIG.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    data = loaded
        except Exception:
            data = {}
        data.update({
            "actions": self.actions,
            "delay": self.delay,
            "startup": self.startup,
            "close_to_tray": self.close_to_tray,
            "auto_update_enabled": self.auto_update_enabled,
            "selected_media_app": self.selected_media_app.get(),
        })
        CONFIG.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def check_legal_acceptance_on_startup(self):
        """Check legal acceptance on startup and show popup if needed"""
        # Check if legal acceptance is required for this version
        if not self.check_legal_acceptance():
            # Show legal popup
            self.show_legal_popup()

    def set_startup(self, enabled):
        self.startup = bool(enabled)
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY, 0, winreg.KEY_SET_VALUE)
            if self.startup:
                if getattr(sys, "frozen", False):
                    command = f'"{sys.executable}" --startup'
                else:
                    script = str(Path(__file__).resolve())
                    pythonw = sys.executable.replace("python.exe", "pythonw.exe")
                    command = f'"{pythonw}" "{script}" --startup'
                winreg.SetValueEx(key, STARTUP_NAME, 0, winreg.REG_SZ, command)
            else:
                try:
                    winreg.DeleteValue(key, STARTUP_NAME)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
        except Exception as e:
            self.log_line("Startup setting error: " + str(e))
        self.save()
        self.startup_var.set(self.startup)

    def set_close_to_tray(self):
        self.close_to_tray = bool(self.close_tray_var.get())
        self.save()
        self.log_line("Close button: " + ("send to tray" if self.close_to_tray else "exit VibePause"))

    def set_auto_update_enabled(self, enabled):
        """Handle auto-update enabled/disabled from settings checkbox"""
        self.auto_update_enabled = bool(enabled)
        self.save()
        if self.auto_update_enabled:
            self.start_auto_update_checker()
        else:
            self.stop_auto_update_checker()
        self.log_line(f"Automatic update checking: {'enabled' if self.auto_update_enabled else 'disabled'}")

    def set_active(self, active):
        """Handle active/inactive state from settings checkbox"""
        self.active = bool(active)
        self.save()
        if self.active:
            self.start_monitoring()
        else:
            self.stop_monitoring()
        self.log_line(f"VibePause: {'active' if self.active else 'inactive'}")

    def load_auto_update_settings(self):
        """Load auto-update enabled setting from config"""
        try:
            if CONFIG.exists():
                d = json.loads(CONFIG.read_text(encoding="utf-8"))
                self.auto_update_enabled = d.get("auto_update_enabled", True)
        except Exception:
            self.auto_update_enabled = True  # Default to enabled

    def load_assets(self):
        if not self.asset_dir.exists():
            return
        # Every UI icon is a PNG, explicitly resized. Source files are 64px and never shown at native size.
        sizes = {
            "play": 17, "pause": 17, "none": 14, "gear": 16,
            "status_play": 14, "status_pause": 14, "monitor": 16, "close": 16, "reset": 16,
            "chrome": 20, "youtube_music": 20, "apple_music": 20, "spotify": 20,
            "vibepause_logo_16": 16, "vibepause_logo_20": 20, "vibepause_logo_24": 24, "vibepause_logo_32": 32,
            "check_on": 18, "check_off": 18,
            "ev_combat": 18, "ev_start": 18, "ev_shop": 18, "ev_finish": 18,
            "ev_lobby": 18, "ev_agent": 18, "ev_ult": 18, "ev_death": 18,
        }
        for name, size in sizes.items():
            path = self.asset_dir / f"{name}.png"
            if path.exists():
                try:
                    im = Image.open(path).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS)
                    self.assets[name] = ImageTk.PhotoImage(im)
                except Exception:
                    pass
        # Death icon is generated locally so no extra asset file is required.
        if "ev_death" not in self.assets:
            try:
                im = Image.new("RGBA", (18, 18), (0, 0, 0, 0))
                d = ImageDraw.Draw(im)
                d.ellipse((2, 2, 16, 16), outline=(255, 70, 85, 255), width=2)
                d.line((6, 6, 12, 12), fill=(255, 70, 85, 255), width=2)
                d.line((12, 6, 6, 12), fill=(255, 70, 85, 255), width=2)
                self.assets["ev_death"] = ImageTk.PhotoImage(im)
            except Exception:
                pass
        try:   # hero banner is already drawn at its exact display size
            self.assets["hero_bg"] = ImageTk.PhotoImage(Image.open(self.asset_dir / "hero_bg.png").convert("RGB"))
        except Exception:
            pass

    def img(self, name):
        return self.assets.get(name)

    def toplevel_hwnd(self):
        # Tk's winfo_id() is the inner client window. The real top-level window
        # (the one the taskbar / Alt+Tab / DWM see) is its parent.
        child = self.root.winfo_id()
        return user32.GetParent(child) or child

    def apply_windows_app_style(self):
        """Custom chrome without overrideredirect().

        The window stays a real, normal Win32 top-level window (so it keeps
        focus, a taskbar button and an Alt+Tab entry), but it has no caption,
        no sizing frame and no maximize box, so Windows draws no title bar and
        no border. Fixed size: no WS_THICKFRAME, no hit-testing, no resizing.
        """
        if os.name != "nt":
            return
        try:
            self.root.update_idletasks()
            hwnd = self.toplevel_hwnd()
            GWL_STYLE, GWL_EXSTYLE = -16, -20
            WS_POPUP, WS_SYSMENU, WS_MINIMIZEBOX = 0x80000000, 0x00080000, 0x00020000
            WS_CAPTION, WS_THICKFRAME, WS_MAXIMIZEBOX, WS_BORDER = 0x00C00000, 0x00040000, 0x00010000, 0x00800000
            WS_EX_APPWINDOW, WS_EX_TOOLWINDOW = 0x00040000, 0x00000080
            style = user32.GetWindowLongPtrW(hwnd, GWL_STYLE)
            style |= WS_POPUP | WS_SYSMENU | WS_MINIMIZEBOX   # minimize box only so the taskbar button can minimize/restore
            style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MAXIMIZEBOX | WS_BORDER)
            user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style)
            ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
            ex = (ex | WS_EX_APPWINDOW) & ~WS_EX_TOOLWINDOW
            user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex)

            IMAGE_ICON, LR_LOADFROMFILE, WM_SETICON = 1, 0x10, 0x0080
            self._hicon_big = user32.LoadImageW(None, str(self.icon_path), IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
            self._hicon_small = user32.LoadImageW(None, str(self.icon_path), IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
            if self._hicon_big:
                user32.SendMessageW(hwnd, WM_SETICON, 1, self._hicon_big)
            if self._hicon_small:
                user32.SendMessageW(hwnd, WM_SETICON, 0, self._hicon_small)

            SWP_NOMOVE, SWP_NOSIZE, SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED = 0x2, 0x1, 0x4, 0x10, 0x20
            user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED)
            # Windows can refresh the non-client icon when the frame changes.
            if self._hicon_big:
                user32.SendMessageW(hwnd, WM_SETICON, 1, self._hicon_big)
            if self._hicon_small:
                user32.SendMessageW(hwnd, WM_SETICON, 0, self._hicon_small)
        except Exception:
            pass

    # ---------- custom window ----------
    def start_drag(self, event):
        # Move the window with one cheap Win32 call per mouse event (no Tk geometry/relayout,
        # which caused the ghosting, and no native modal move loop inside a Tk callback).
        self.drag_x = event.x_root - self.root.winfo_x()
        self.drag_y = event.y_root - self.root.winfo_y()
        self._drag_hwnd = None
        if os.name == "nt":
            try:
                self._drag_hwnd = self.toplevel_hwnd()
            except Exception:
                self._drag_hwnd = None

    def drag_window(self, event):
        x, y = event.x_root - self.drag_x, event.y_root - self.drag_y
        if self._drag_hwnd:
            SWP_NOSIZE, SWP_NOZORDER, SWP_NOACTIVATE = 0x1, 0x4, 0x10
            user32.SetWindowPos(self._drag_hwnd, None, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
        else:
            self.root.geometry(f"+{x}+{y}")

    def bind_drag(self, *widgets):
        for w in widgets:
            w.bind("<ButtonPress-1>", self.start_drag)
            w.bind("<B1-Motion>", self.drag_window)

    def build(self):
        self.build_titlebar()
        self.body = tk.Frame(self.root, bg=self.BG, bd=0, highlightthickness=0)
        self.body.pack(fill="both", expand=True)
        self.build_main()

    def build_titlebar(self):
        bar = tk.Frame(self.root, bg=self.TOP, height=56)
        bar.pack(fill="x")
        tk.Frame(self.root, bg=self.RED, height=2).pack(fill="x")

        left = tk.Frame(bar, bg=self.TOP)
        left.pack(side="left", fill="y", padx=18)
        logo = tk.Label(left, image=self.img("vibepause_logo_32"), bg=self.TOP)
        logo.pack(side="left", padx=(0, 10))
        title = tk.Label(left, text="VIBEPAUSE", bg=self.TOP, fg=self.TEXT, font=self.F(14, True))
        title.pack(side="left")
        self.bind_drag(bar, left, logo, title)

        controls = tk.Frame(bar, bg=self.TOP)
        controls.pack(side="right", fill="y")
        self.close_tray_var = tk.BooleanVar(value=self.close_to_tray)
        self.startup_var = tk.BooleanVar(value=self.startup)
        ImgCheck(controls, "Run on Startup", self.startup_var, lambda: self.set_startup(self.startup_var.get()),
                 {True: self.img("check_on"), False: self.img("check_off")},
                 self.TOP, self.TEXT, self.F(10)).pack(side="left", padx=(0, 10), pady=16)
        self.auto_update_var = tk.BooleanVar(value=self.auto_update_enabled)
        ImgCheck(controls, "Automatically check for updates", self.auto_update_var,
                 lambda: self.set_auto_update_enabled(self.auto_update_var.get()),
                 {True: self.img("check_on"), False: self.img("check_off")},
                 self.TOP, self.TEXT, self.F(10)).pack(side="left", padx=(0, 10), pady=16)
        self.active_var = tk.BooleanVar(value=self.active)
        ImgCheck(controls, "Active", self.active_var,
                 lambda: self.set_active(self.active_var.get()),
                 {True: self.img("check_on"), False: self.img("check_off")},
                 self.TOP, self.TEXT, self.F(10)).pack(side="left", padx=(0, 10), pady=16)
        self.settings_btn = tk.Button(controls, image=self.img("gear"), command=self.toggle_settings,
                                      bg=self.TOP, activebackground=self.PANEL3, relief="flat", bd=0,
                                      padx=12, pady=8, cursor="hand2")
        self.settings_btn.pack(side="left", fill="y")
        close = tk.Button(controls, image=self.img("close"), command=self.on_window_close,
                          bg=self.TOP, activebackground=self.DRED, relief="flat", bd=0,
                          padx=14, pady=8, cursor="hand2")
        close.pack(side="left", fill="y")
        close.bind("<Enter>", lambda e: close.config(bg=self.RED))
        close.bind("<Leave>", lambda e: close.config(bg=self.TOP))

    def panel(self, parent, title):
        outer = tk.Frame(parent, bg=self.PANEL, highlightbackground=self.BORDER, highlightthickness=1)
        head = tk.Frame(outer, bg=self.PANEL)
        head.pack(fill="x", padx=12, pady=(10, 6))
        tk.Frame(head, bg=self.RED, width=4, height=13).pack(side="left")
        tk.Label(head, text=title, bg=self.PANEL, fg=self.TEXT, font=self.F(10, True)).pack(side="left", padx=(8, 0))
        body = tk.Frame(outer, bg=self.PANEL)
        body.pack(fill="both", expand=True, padx=12, pady=(0, 10))
        return outer, body, head

    def build_main(self):
        for w in self.body.winfo_children():
            w.destroy()
        main = tk.Frame(self.body, bg=self.BG)
        main.pack(fill="both", expand=True, padx=24, pady=16)

        top = tk.Frame(main, bg=self.BG)
        top.pack(fill="x", pady=(0, 12))
        self.monitor = tk.Label(top, image=self.img("monitor"), compound="left", text="  Monitoring Valorant...",
                                bg=self.BG, fg=self.GREEN, font=self.F(11))
        self.monitor.pack(side="left")
        tk.Label(top, text="GLOBAL WINDOWS MEDIA CONTROLS", bg=self.BG, fg="#5d6b7b", font=self.F(8, True)).pack(side="right")

        # Hero: banner image + live text drawn on a canvas
        hero = tk.Canvas(main, width=990, height=104, bg=self.PANEL, bd=0, highlightthickness=1,
                         highlightbackground=self.BORDER)
        hero.pack(fill="x", pady=(0, 12))
        if self.img("hero_bg"):
            hero.create_image(0, 0, image=self.img("hero_bg"), anchor="nw")
        hero.create_text(24, 14, text="CURRENT GAME STATE", fill=self.MUTED, font=self.F(9, True), anchor="nw")
        self.hero_event = hero.create_text(24, 32, text="WAITING FOR VALORANT", fill=self.TEXT, font=self.F(24, True), anchor="nw")
        self.hero_icon = hero.create_image(26, 86, image=self.img("status_play"), anchor="w")
        self.hero_music = hero.create_text(46, 86, text="Music is Playing", fill=self.GREEN, font=self.F(10, True), anchor="w")
        hero.create_text(960, 52, text="MEDIA\nCONTROL", fill="#ffffff", font=self.F(15, True), anchor="e", justify="right")
        self.hero = hero

        columns = tk.Frame(main, bg=self.BG)
        columns.pack(fill="both", expand=True)
        left_col = tk.Frame(columns, bg=self.BG)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 7))
        right_col = tk.Frame(columns, bg=self.BG, width=330)
        right_col.pack(side="right", fill="both", padx=(7, 0))
        right_col.pack_propagate(False)

        self.build_events(left_col)
        self.build_right(right_col)

        foot = tk.Frame(main, bg=self.BG)
        foot.pack(anchor="w", pady=(10, 0))
        for t in ("Made using Claude by tanveer-exe",):
            tk.Label(foot, text=t, bg=self.BG, fg="#5d6b7b", font=self.F(8)).pack(side="left")
        tk.Frame(foot, bg=self.RED, width=4, height=4).pack(side="left", padx=8)
        tk.Label(foot, text="Open Source", bg=self.BG, fg="#5d6b7b", font=self.F(8)).pack(side="left")

    EVENT_ICON = {
        "Combat Start": "ev_combat", "Player Eliminated": "ev_death", "Match Started": "ev_start", "Buy Phase Started": "ev_shop",
        "Match Ended": "ev_finish", "Returned to Lobby": "ev_lobby", "Agent Selection": "ev_agent",
        "Ultimate Used": "ev_ult",
    }

    def build_events(self, parent):
        outer, body, head = self.panel(parent, "MUSIC BEHAVIOUR")
        outer.pack(fill="both", expand=True)
        reset_btn = tk.Button(head, image=self.img("reset"), command=self.reset, bg=self.PANEL2,
                              activebackground=self.PANEL3, relief="flat", bd=0, padx=8, pady=5, cursor="hand2")
        reset_btn.pack(side="right")
        tk.Label(body, text="Click an action icon to cycle:  None  >  Play  >  Pause", bg=self.PANEL, fg=self.MUTED,
                 font=self.F(9)).pack(anchor="w", pady=(0, 8))

        for name, desc in EVENTS:
            row = tk.Frame(body, bg=self.PANEL2)
            row.pack(fill="x", pady=2)
            stripe = tk.Frame(row, bg=self.PANEL3, width=3)
            stripe.pack(side="left", fill="y")
            self.action_stripe[name] = stripe
            tk.Label(row, image=self.img(self.EVENT_ICON[name]), bg=self.PANEL2).pack(side="left", padx=(12, 8), pady=8)
            tk.Label(row, text=name, bg=self.PANEL2, fg=self.TEXT, font=self.F(10, True),
                     anchor="w").pack(side="left", padx=(0, 8))
            tk.Label(row, text=desc, bg=self.PANEL2, fg=self.MUTED, font=self.F(9),
                     anchor="w").pack(side="left", fill="x", expand=True)
            v = tk.StringVar(value=self.actions[name])
            self.action_vars[name] = v
            b = tk.Button(row, image=self.img("none"), width=28, height=24, bd=0, relief="flat",
                          command=lambda n=name, var=v: self.cycle_choice(n, var), cursor="hand2")
            b.pack(side="right", padx=9, pady=5)
            self.action_button[name] = b
            self.refresh_action(name, v)

    def refresh_action(self, event, var):
        value = var.get()
        b = self.action_button[event]
        icon_name = {"None": "none", "Play": "play", "Pause": "pause"}.get(value, "none")
        bg, stripe = {"Pause": ("#4a1d27", self.RED), "Play": ("#0f3b3a", self.GREEN)}.get(value, (self.PANEL3, self.PANEL3))
        b.config(image=self.img(icon_name), bg=bg, activebackground=bg)
        self.action_stripe[event].config(bg=stripe)

    def cycle_choice(self, event, var):
        order = ["None", "Play", "Pause"]
        value = order[(order.index(var.get()) + 1) % len(order)]
        var.set(value)
        self.actions[event] = value
        self.refresh_action(event, var)
        self.save()
        self.log_line(f"{event}: {value}")

    def build_right(self, parent):
        outer, controls, _ = self.panel(parent, "MEDIA CONTROLS")
        outer.pack(fill="x", pady=(0, 9))
        play_btn = tk.Button(controls, image=self.img("play"), text="  PLAY", compound="left", command=self.force_play,
                             bg="#0f3b3a", fg=self.GREEN, activebackground="#165252", activeforeground=self.GREEN,
                             relief="flat", bd=0, font=self.F(10, True), pady=8, cursor="hand2")
        play_btn.pack(side="left", fill="x", expand=True, padx=(0, 4))
        pause_btn = tk.Button(controls, image=self.img("pause"), text="  PAUSE", compound="left", command=self.force_pause,
                              bg="#4a1d27", fg=self.RED, activebackground="#652634", activeforeground=self.RED,
                              relief="flat", bd=0, font=self.F(10, True), pady=8, cursor="hand2")
        pause_btn.pack(side="left", fill="x", expand=True, padx=(4, 0))


        outer, apps, _ = self.panel(parent, "SUPPORTED MEDIA")
        outer.pack(fill="x", pady=(0, 9))
        tk.Label(apps, text="Controlled via Windows media session", bg=self.PANEL, fg=self.MUTED,
                 font=self.F(8)).pack(anchor="w", pady=(0, 8))
        grid = tk.Frame(apps, bg=self.PANEL)
        grid.pack(fill="x")
        labels = {"Google Chrome": "Chrome", "YouTube Music": "YouTube Music", "Apple Music": "Apple Music", "Spotify": "Spotify"}
        for i, name in enumerate(MEDIA_APPS):
            chip = tk.Frame(grid, bg=self.PANEL2, highlightbackground=self.BORDER, highlightthickness=1)
            chip.grid(row=i // 2, column=i % 2, sticky="ew", padx=3, pady=3)
            grid.columnconfigure(i % 2, weight=1)
            if self.img({"Google Chrome": "chrome", "YouTube Music": "youtube_music",
                         "Apple Music": "apple_music", "Spotify": "spotify"}[name]):
                self.make_app_icon(chip, name).pack(side="left", padx=(8, 0), pady=6)
            tk.Label(chip, text=labels[name], bg=self.PANEL2, fg=self.TEXT, font=self.F(9, True)).pack(side="left", padx=(8, 6), pady=6)

        outer, body, head = self.panel(parent, "LIVE ACTIVITY")
        outer.pack(fill="both", expand=True)
        tk.Button(head, text="CLEAR", command=self.clear_log, bg=self.PANEL2, fg=self.TEXT, activebackground=self.PANEL3,
                  activeforeground=self.TEXT, relief="flat", bd=0, padx=8, pady=2, font=self.F(8, True),
                  cursor="hand2").pack(side="right")
        self.log = tk.Text(body, bg="#0b1119", fg="#b9c2d0", insertbackground="white", relief="flat", bd=0,
                           font=("Consolas", 8), wrap="word", height=4, highlightthickness=0)
        self.log.pack(fill="both", expand=True)

    def make_app_icon(self, parent, name):
        key = {"Google Chrome": "chrome", "YouTube Music": "youtube_music",
               "Apple Music": "apple_music", "Spotify": "spotify"}[name]
        return tk.Label(parent, image=self.img(key), bg=self.PANEL2)

    def toggle_settings(self):
        if self.settings_open:
            self.close_settings()
            return
        self.settings_open = True
        bg = self.TOP
        overlay = tk.Frame(self.root, bg=bg, highlightbackground=self.RED, highlightthickness=1)
        overlay.place(relx=1.0, x=-18, y=66, anchor="ne", width=330, height=372)
        self.settings_overlay = overlay
        tk.Label(overlay, text="SETTINGS", bg=bg, fg=self.TEXT, font=self.F(15, True)).pack(anchor="w", padx=18, pady=(16, 4))
        ImgCheck(overlay, "Close button sends to tray", self.close_tray_var, self.set_close_to_tray,
                 {True: self.img("check_on"), False: self.img("check_off")},
                 bg, self.TEXT, self.F(10)).pack(anchor="w", padx=18, pady=(2, 6))
        tk.Label(overlay, text="Unticked: the X button exits VibePause completely.",
                 bg=bg, fg=self.MUTED, font=self.F(9), wraplength=290, justify="left").pack(anchor="w", padx=18, pady=(0, 6))
        tk.Label(overlay, text="Event delay", bg=bg, fg=self.TEXT, font=self.F(10)).pack(anchor="w", padx=18, pady=(8, 4))
        row = tk.Frame(overlay, bg=bg)
        row.pack(fill="x", padx=18)
        self.delay_settings = tk.StringVar(value=str(self.delay))
        vcmd = (self.root.register(lambda v: v == "" or (v.isdigit() and len(v) <= 6)), "%P")
        entry = tk.Entry(row, textvariable=self.delay_settings, width=9, bg=self.PANEL2, fg=self.TEXT,
                         insertbackground="white", relief="flat", bd=0, validate="key", validatecommand=vcmd,
                         selectbackground="#2f6fd6", selectforeground="white", font=self.F(11),
                         highlightthickness=1, highlightbackground=self.BORDER, highlightcolor=self.RED,
                         takefocus=True, state="normal", exportselection=False)
        entry.pack(side="left", ipady=5)
        # Tk's Entry maps Ctrl+A to "start of line" on Windows; make it Select All.
        def select_all(e):
            e.widget.select_range(0, "end"); e.widget.icursor("end"); return "break"
        entry.bind("<Control-a>", select_all)
        entry.bind("<Control-A>", select_all)
        entry.bind("<Return>", lambda e: self.save_settings_page())
        entry.bind("<Button-1>", lambda e: e.widget.focus_set())
        self.delay_entry = entry
        entry.after(50, lambda: (entry.focus_force(), entry.select_range(0, "end")))
        tk.Label(row, text="milliseconds", bg=bg, fg=self.MUTED, font=self.F(9)).pack(side="left", padx=8)
        tk.Button(overlay, text="CHECK FOR UPDATES", command=self.check_for_updates,
                  bg=self.PANEL2, fg=self.TEXT, activebackground=self.PANEL3, activeforeground=self.TEXT,
                  relief="flat", bd=0, padx=14, pady=7, font=self.F(9, True), cursor="hand2").pack(anchor="w", padx=18, pady=(10, 6))
        self.update_status = tk.Label(overlay, text=f"VibePause {APP_VERSION}", bg=bg, fg=self.MUTED, font=self.F(8),
                                      wraplength=294, justify="left", anchor="nw", height=3)
        self.update_status.pack(anchor="w", fill="x", padx=18, pady=(0, 2))
        tk.Button(overlay, text="SAVE SETTINGS", command=self.save_settings_page,
                  bg=self.RED, fg="white", activebackground="#ff6a77", activeforeground="white", relief="flat", bd=0,
                  padx=14, pady=7, font=self.F(9, True), cursor="hand2", width=27, height=1).pack(anchor="w", padx=18, pady=(8, 14))

    def check_for_updates(self):
        """Settings > CHECK FOR UPDATES. Runs the network work off the UI thread."""
        if getattr(self, "_update_busy", False):
            return
        self._update_busy = True
        self._set_update_status("Checking for updates...", self.BLUE)
        threading.Thread(target=self._check_for_updates_worker, daemon=True).start()

    def _set_update_status(self, text, color=None):
        if hasattr(self, "update_status"):
            try:
                self.update_status.config(text=text, fg=color or self.MUTED)
            except tk.TclError:
                pass   # settings panel was closed meanwhile

    def _check_for_updates_worker(self):
        try:
            result = pick_update(fetch_releases(), APP_VERSION)
            if result[0] == "update":
                self.event("update", ("available",) + result[1:])
            else:
                self.event("update", ("current", result[1]))
        except UpdateError as e:
            self.event("update", ("error", str(e)))
        except Exception as e:
            self.event("update", ("error", f"Update check failed ({type(e).__name__}: {e or 'no details'})."))

    def handle_update_event(self, value):
        kind = value[0]
        if kind == "current":
            self._update_busy = False
            msg = f"No update found. VibePause {APP_VERSION} is the latest version."
            self._set_update_status(msg, self.GREEN)
            self.log_line(msg)
        elif kind == "available":
            self._update_busy = False
            _, latest, url, size = value
            self._set_update_status(f"Update found: VibePause {latest} is available.", self.GREEN)
            self.log_line(f"Update found: {latest} (current {APP_VERSION})")

            # Show different notifications based on app state and auto-update setting
            if self.auto_update_enabled:
                # For auto-update enabled, show actionable notification
                answer = messagebox.askyesnocancel(
                    "VibePause Update",
                    f"VibePause {latest} is available.\n\n"
                    f"Current version: {APP_VERSION}\n"
                    f"New version: {latest}\n\n"
                    "Download and install it now?\n\n"
                    "Yes: Update now\n"
                    "No: Remind me later\n"
                    "Cancel: Don't remind again",
                    parent=self.root)

                if answer is True:  # Yes
                    self._update_busy = True
                    self._set_update_status("Updating: downloading installer...", self.BLUE)
                    threading.Thread(target=self._download_update_worker, args=(latest, url, size), daemon=True).start()
                elif answer is False:  # No (Remind me later)
                    # Could implement snooze functionality here
                    pass
                # If answer is None (Cancel), do nothing
            else:
                # For auto-update disabled, just inform user
                messagebox.showinfo(
                    "Update Available",
                    f"VibePause {latest} is available.\n\n"
                    f"Current version: {APP_VERSION}\n"
                    f"New version: {latest}\n\n"
                    "Open Settings and click 'Check for updates' to download and install.",
                    parent=self.root)

        elif kind == "progress":
            self._set_update_status(f"Updating: downloading installer... {value[1]}%", self.BLUE)
        elif kind == "downloaded":
            self._launch_update(value[1], value[2])
        elif kind == "error":
            self._update_busy = False
            self._set_update_status(value[1], self.RED)
            self.log_line(value[1])

    def background_update_checker(self):
        """Background thread for periodic update checks"""
        while getattr(self, '_auto_update_running', False):
            try:
                current_time = time.time()
                if current_time - self.last_update_check >= UPDATE_CHECK_INTERVAL:
                    # Silent check (no UI prompts)
                    update_available, version, url, size = self._silent_check_for_updates()

                    if update_available:
                        self.last_update_check = current_time
                        # Show notification - different behavior based on auto-update setting
                        if self.auto_update_enabled:
                            # Show actionable notification when auto-update is enabled
                            self.root.after(0, lambda v=(version, url, size): self._show_update_notification(v))
                        else:
                            # Show informational notification when auto-update is disabled
                            self.root.after(0, lambda v=(version,): self._show_update_notification_disabled(v))

                # Wait interruptibly so shutdown wakes the checker immediately.
                if self._auto_update_stop.wait(60):
                    break
            except Exception as e:
                print(f"Background update check error: {e}")
                if self._auto_update_stop.wait(60):
                    break

    def _silent_check_for_updates(self):
        """Silently check for updates, return (update_available, version, url, size)"""
        try:
            result = pick_update(fetch_releases(), APP_VERSION)
            if result[0] == "update":
                return True, result[1], result[2], result[3]
            else:
                return False, result[1], "", 0
        except Exception:
            # Silently fail for background checks
            return False, "", "", 0

    def _show_update_notification(self, version_info):
        """Show update notification when auto-update is enabled"""
        version, url, size = version_info
        result = messagebox.askyesnocancel(
            "Update Available",
            f"VibePause {version} is available!\n\n"
            "Would you like to download and install it now?\n\n"
            "Yes: Download and install\n"
            "No: Remind me later\n"
            "Cancel: Don't remind again",
            parent=self.root,
            icon='question'
        )

        if result is True:  # Yes
            self._update_busy = True
            self._set_update_status("Updating: downloading installer...", self.BLUE)
            threading.Thread(target=self._download_update_worker, args=(version, url, size), daemon=True).start()
        elif result is False:  # No (Remind me later)
            # User chose "Remind me later" - could implement snooze functionality
            pass
        # If result is None (Cancel), do nothing

    def _show_update_notification_disabled(self, version_info):
        """Show update notification when auto-update is disabled"""
        version = version_info[0]
        messagebox.showinfo(
            "Update Available",
            f"VibePause {version} is available.\n\n"
            "Automatic update checking is disabled.\n"
            "Open Settings and click 'Check for updates' to download and install.",
            parent=self.root
        )

    def _download_update_worker(self, latest, url, expected_size):
        try:
            fd, path = tempfile.mkstemp(prefix="VibePause_Setup_", suffix=".exe")
            os.close(fd)
            req = urllib.request.Request(url, headers={"User-Agent": f"VibePause/{APP_VERSION}"})
            done, last_pct = 0, -1
            with urllib.request.urlopen(req, timeout=30) as resp, open(path, "wb") as out:
                total = int(resp.headers.get("Content-Length") or expected_size or 0)
                while True:
                    chunk = resp.read(1024 * 256)
                    if not chunk:
                        break
                    out.write(chunk)
                    done += len(chunk)
                    if total:
                        pct = min(100, done * 100 // total)
                        if pct != last_pct and pct % 5 == 0:
                            last_pct = pct
                            self.event("update", ("progress", pct))
            if expected_size and done != expected_size:
                raise UpdateError("The downloaded installer is incomplete. Please try again.")
            self.event("update", ("downloaded", path, latest))
        except UpdateError as e:
            self.event("update", ("error", str(e)))
        except Exception as e:
            self.event("update", ("error", f"Update download failed ({type(e).__name__}: {e or 'no details'})."))

    def _launch_update(self, path, latest):
        try:
            self.log_line(f"Starting the VibePause {latest} installer")
            DETACHED_PROCESS, CREATE_NEW_PROCESS_GROUP = 0x00000008, 0x00000200
            subprocess.Popen([path], close_fds=True, creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP)
            self.complete_exit()   # stop monitoring, remove tray icon, quit so the installer can replace files
        except Exception as e:
            self._update_busy = False
            self._set_update_status(f"Could not start the installer: {e}", self.RED)

    def start_auto_update_checker(self):
        """Start the background update checking thread"""
        if not getattr(self, '_auto_update_running', False):
            self._auto_update_running = True
            if not hasattr(self, "_auto_update_stop"):
                self._auto_update_stop = threading.Event()
            self._auto_update_stop.clear()
            self.auto_update_thread = threading.Thread(
                target=self.background_update_checker,
                daemon=True
            )
            self.auto_update_thread.start()

    def stop_auto_update_checker(self):
        """Stop the background update checking thread"""
        self._auto_update_running = False
        # Wake the checker immediately instead of waiting for its 60-second
        # polling sleep. This keeps application shutdown from appearing frozen.
        if hasattr(self, "_auto_update_stop"):
            self._auto_update_stop.set()
        # Do not block the Tk UI waiting for a network thread. The checker is
        # daemonized and will exit on its own after the stop event is signaled.

    def check_legal_acceptance(self):
        """Check if legal documents have been accepted for current version"""
        try:
            if CONFIG.exists():
                d = json.loads(CONFIG.read_text(encoding="utf-8"))
                return d.get(LEGAL_ACCEPTANCE_KEY, False)
        except Exception:
            pass
        return False

    def save_legal_acceptance(self):
        """Save that legal documents have been accepted for current version"""
        try:
            APPDATA.mkdir(parents=True, exist_ok=True)
            # Load existing settings
            if CONFIG.exists():
                d = json.loads(CONFIG.read_text(encoding="utf-8"))
            else:
                d = {}
            # Update legal acceptance
            d[LEGAL_ACCEPTANCE_KEY] = True
            # Save back
            CONFIG.write_text(json.dumps(d, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"Failed to save legal acceptance: {e}")

    def show_legal_popup(self):
        """Show terms and conditions and privacy policy popup"""
        W, H = 640, 560
        legal_window = tk.Toplevel(self.root)
        legal_window.title("Legal Agreement")
        legal_window.configure(bg=self.BG)
        legal_window.resizable(False, False)
        legal_window.transient(self.root)  # Stay on top of main window

        # Center over the main window (fall back to the screen if it is hidden)
        legal_window.update_idletasks()
        if self.root.winfo_viewable():
            x = self.root.winfo_x() + (self.root.winfo_width() - W) // 2
            y = self.root.winfo_y() + (self.root.winfo_height() - H) // 2
        else:
            x = (legal_window.winfo_screenwidth() - W) // 2
            y = (legal_window.winfo_screenheight() - H) // 2
        legal_window.geometry(f"{W}x{H}+{max(0, x)}+{max(0, y)}")

        # Layout order matters with pack: the button bar is packed FIRST on the
        # bottom edge so the text area can never squeeze it out of the window.
        button_frame = tk.Frame(legal_window, bg=self.BG)
        button_frame.pack(side="bottom", fill="x", padx=20, pady=(8, 20))

        tab_frame = tk.Frame(legal_window, bg=self.BG)
        tab_frame.pack(side="top", fill="x", padx=20, pady=(20, 10))

        content_frame = tk.Frame(legal_window, bg="#0b1119")
        content_frame.pack(side="top", fill="both", expand=True, padx=20)

        scrollbar = tk.Scrollbar(content_frame, orient="vertical", relief="flat", bd=0)
        scrollbar.pack(side="right", fill="y")

        # ONE text widget that is re-filled on every tab switch. (Destroying and
        # re-creating the container is what left the tabs blank before.)
        text_widget = tk.Text(content_frame, bg="#0b1119", fg="#b9c2d0",
                              insertbackground="white", relief="flat", bd=0,
                              highlightthickness=0, font=self.F(10), wrap="word",
                              padx=14, pady=12, spacing1=2, spacing3=4,
                              yscrollcommand=scrollbar.set, cursor="arrow")
        text_widget.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=text_widget.yview)

        text_widget.tag_configure("h1", font=self.F(15, True), foreground="#ece8e1",
                                  spacing1=4, spacing3=10)
        text_widget.tag_configure("h2", font=self.F(12, True), foreground="#ece8e1",
                                  spacing1=14, spacing3=4)
        text_widget.tag_configure("h3", font=self.F(10, True), foreground="#ece8e1",
                                  spacing1=10, spacing3=2)
        text_widget.tag_configure("bullet", lmargin1=14, lmargin2=28)

        def read_doc(filename, title):
            try:
                path = RESOURCE_DIR / filename
                if path.exists():
                    return path.read_text(encoding="utf-8")
                return f"# {title}\n\n{title} file not found."
            except Exception:
                return f"# {title}\n\nError loading {title.lower()}."

        def render_markdown(raw):
            for line in raw.replace("\r\n", "\n").split("\n"):
                line = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", line)
                line = re.sub(r"\*\*(.+?)\*\*", r"\1", line)
                line = line.replace("`", "")
                stripped = line.lstrip()
                if stripped.startswith("### "):
                    text_widget.insert("end", stripped[4:] + "\n", "h3")
                elif stripped.startswith("## "):
                    text_widget.insert("end", stripped[3:] + "\n", "h2")
                elif stripped.startswith("# "):
                    text_widget.insert("end", stripped[2:] + "\n", "h1")
                elif stripped.startswith(("- ", "* ")):
                    text_widget.insert("end", "•  " + stripped[2:] + "\n", "bullet")
                else:
                    text_widget.insert("end", line + "\n")

        docs = {
            "terms": ("TERMS_AND_CONDITIONS.md", "Terms and Conditions"),
            "privacy": ("PRIVACY_POLICY.md", "Privacy Policy"),
        }
        tabs = {}

        def show_doc(which):
            filename, title = docs[which]
            for key, label in tabs.items():
                active = key == which
                label.config(bg=self.PANEL2 if active else self.PANEL,
                             fg=self.TEXT if active else self.MUTED)
            text_widget.config(state="normal")
            text_widget.delete("1.0", "end")
            render_markdown(read_doc(filename, title))
            text_widget.config(state="disabled")
            text_widget.yview_moveto(0)

        for key, caption in (("terms", "Terms and Conditions"), ("privacy", "Privacy Policy")):
            label = tk.Label(tab_frame, text=caption, bg=self.PANEL, fg=self.MUTED,
                             font=self.F(10, True), padx=20, pady=10, cursor="hand2")
            label.pack(side="left", padx=(0, 8))
            label.bind("<Button-1>", lambda e, k=key: show_doc(k))
            tabs[key] = label

        show_doc("terms")

        def accept_legal():
            self.save_legal_acceptance()
            try:
                legal_window.grab_release()
            except tk.TclError:
                pass
            legal_window.destroy()

        accept_btn = tk.Button(button_frame, text="I Agree", command=accept_legal,
                               bg=self.RED, fg="white", activebackground="#ff6a77",
                               activeforeground="white", relief="flat", bd=0,
                               font=self.F(11, True), padx=40, pady=12, cursor="hand2")
        accept_btn.pack(side="right")

        def finish_setup():
            try:
                legal_window.lift()
                legal_window.grab_set()  # Modal behavior
                accept_btn.focus_set()
            except tk.TclError:
                pass

        legal_window.after(100, finish_setup)

    def close_settings(self):
        self.settings_open = False
        if hasattr(self, "settings_overlay"):
            self.settings_overlay.destroy()

    def reset(self):
        self.actions = DEFAULT_ACTIONS.copy()
        for k, v in self.action_vars.items():
            v.set(self.actions[k])
            self.refresh_action(k, v)
        self.delay = 0
        self.save()
        self.log_line("Reset to default")

    def save_settings_page(self):
        try:
            self.delay = max(0, int(self.delay_settings.get()))
        except Exception:
            self.delay = 0
        self.save()
        self.log_line("Settings saved")
        self.close_settings()

    def start_monitoring(self):
        self.actions = {k: v.get() for k, v in self.action_vars.items()}
        self.save()
        self.running = True
        self.controller.start(self.actions, self.delay)
        self.status_update(True)
        self.log_line("VibePause started automatically")

    def stop_monitoring(self):
        self.running = False
        self.controller.stop()
        self.status_update(False)
        self.log_line("VibePause stopped")

    def status_update(self, active):
        self.monitor.config(image=self.img("monitor"),
                            text=("  Monitoring Valorant..." if active else "  Waiting for Valorant..."),
                            fg=self.GREEN if active else self.MUTED)

    def set_music_status(self, playing):
        self.hero.itemconfig(self.hero_icon, image=self.img("status_play" if playing else "status_pause"))
        self.hero.itemconfig(self.hero_music, text="Music is Playing" if playing else "Music is Paused",
                             fill=self.GREEN if playing else "#ffd1d5")

    def force_play(self):
        self._manual(True)

    def force_pause(self):
        self._manual(False)

    def _manual(self, desired):
        def work():
            if self.controller.set_playing(desired):
                self.event("music", "Playing" if desired else "Paused")
                self.event("system", "Manual: " + ("Play" if desired else "Pause"))
        threading.Thread(target=work, daemon=True).start()   # keep the UI responsive

    def start_quit_listener(self):
        """Lets a newly launched copy ask this one to exit cleanly (tray icon
        removed, settings saved) instead of being force-killed."""
        if os.name != "nt":
            return
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateEventW.restype = ctypes.c_void_p
            kernel32.CreateEventW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_wchar_p]
            kernel32.WaitForSingleObject.restype = ctypes.c_uint32
            kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            handle = kernel32.CreateEventW(None, True, False, QUIT_EVENT_NAME)   # manual-reset, unsignaled
        except Exception:
            return
        if not handle:
            return

        def watch():
            while True:
                if kernel32.WaitForSingleObject(handle, 500) == 0:   # WAIT_OBJECT_0: another copy asked us to quit
                    self.event("cmd", "exit")
                    return

        threading.Thread(target=watch, daemon=True).start()

    def event(self, kind, value):
        self.q.put((kind, value))

    def process(self):
        try:
            while True:
                kind, value = self.q.get_nowait()
                now = time.strftime("%H:%M:%S")
                if kind == "cmd":
                    self.run_command(value)
                elif kind == "update":
                    self.handle_update_event(value)
                elif kind == "event":
                    event, action = value
                    self.hero.itemconfig(self.hero_event, text=event.upper())
                    self.log_line(f"{now}  {event}  [{action}]")
                elif kind == "music":
                    self.set_music_status(value == "Playing")
                    self.log_line(f"{now}  Music: {value}")
                else:
                    self.log_line(f"{now}  {value}")
        except queue.Empty:
            pass
        self.root.after(80, self.process)

    def log_line(self, text):
        if not hasattr(self, "log"):
            return
        self.log.insert("end", text + "\n")
        self.log.see("end")
        try:
            if int(self.log.index("end-1c").split(".")[0]) > 220:
                self.log.delete("1.0", "50.0")
        except Exception:
            pass

    def clear_log(self):
        if hasattr(self, "log"):
            self.log.delete("1.0", "end")

    def create_tray(self):
        if not TRAY_AVAILABLE or self.tray_icon:
            return
        try:
            img = Image.open(self.icon_path)
            img.load()
            img = img.convert("RGBA")
        except Exception:
            img = Image.new("RGBA", (64, 64), (20, 20, 20, 255))
        menu = pystray.Menu(
            pystray.MenuItem("Open VibePause", lambda icon, item: self.event("cmd", "open"), default=True),
            pystray.MenuItem("Start VibePause", lambda icon, item: self.event("cmd", "start")),
            pystray.MenuItem("Stop VibePause", lambda icon, item: self.event("cmd", "stop")),
            pystray.MenuItem("Exit VibePause", lambda icon, item: self.event("cmd", "exit")),
        )
        self.tray_icon = pystray.Icon("VibePause", img, APP_NAME, menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def run_command(self, cmd):
        if cmd == "open":
            self._show()
        elif cmd == "start":
            self.start_monitoring()
        elif cmd == "stop":
            self.stop_monitoring()
        elif cmd == "exit":
            self.complete_exit()

    def hide_window(self):
        self.root.withdraw()   # removes the taskbar button and Alt+Tab entry; tray icon stays

    def _show(self):
        self.root.deiconify()
        self.apply_windows_app_style()
        self.root.lift()
        try:
            self.root.focus_force()
        except Exception:
            pass

    def on_window_close(self):
        # "Close to Tray" ticked: hide to the tray. Unticked: quit completely.
        if self.close_to_tray and TRAY_AVAILABLE:
            self.hide_window()
        else:
            self.complete_exit()

    def complete_exit(self):
        # Shutdown must be fast and must never wait on network I/O from the UI.
        self.controller.stop()
        self.stop_auto_update_checker()

        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
            self.tray_icon = None

        try:
            self.save()
        except Exception:
            pass

        try:
            self.root.destroy()
        finally:
            # Background workers are daemon threads, so the process can exit
            # immediately without making the window appear frozen.
            os._exit(0)

def setup_win32():
    """Declare ctypes signatures once so 64-bit handles are never truncated (a classic cause of native crashes)."""
    if os.name != "nt":
        return
    from ctypes import c_void_p, c_int, c_uint, c_size_t, c_ssize_t
    user32.GetParent.restype = c_void_p;            user32.GetParent.argtypes = [c_void_p]
    user32.GetWindowLongPtrW.restype = c_ssize_t;   user32.GetWindowLongPtrW.argtypes = [c_void_p, c_int]
    user32.SetWindowLongPtrW.restype = c_ssize_t;   user32.SetWindowLongPtrW.argtypes = [c_void_p, c_int, c_ssize_t]
    user32.SetWindowPos.restype = c_int;            user32.SetWindowPos.argtypes = [c_void_p, c_void_p, c_int, c_int, c_int, c_int, c_uint]
    user32.SendMessageW.restype = c_ssize_t;        user32.SendMessageW.argtypes = [c_void_p, c_uint, c_size_t, c_void_p]
    user32.LoadImageW.restype = c_void_p;           user32.LoadImageW.argtypes = [c_void_p, ctypes.c_wchar_p, c_uint, c_int, c_int, c_uint]

def set_windows_app_id():
    if os.name != "nt":
        return
    try:
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p("tanveer-exe.VibePause"))
    except Exception:
        pass

INSTANCE_MUTEX_NAME = "VibePauseSingleInstanceMutex"   # also used by the installer (AppMutex)
QUIT_EVENT_NAME = "VibePauseQuitEvent"
ERROR_ALREADY_EXISTS = 183

def already_running():
    """Try to become the single running instance.

    Returns False and keeps the mutex for the life of the process when we are
    the only copy. Returns True when another copy already owns it.
    """
    if os.name != "nt":
        return False
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel32.CreateMutexW(None, False, INSTANCE_MUTEX_NAME)
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            # Release our handle right away. Holding it would keep the mutex
            # alive after the old copy exits, so a retry could never succeed.
            if handle:
                kernel32.CloseHandle(handle)
            return True
        already_running.handle = handle   # kept for process lifetime
        return False
    except Exception:
        return False

def find_other_instance_pids():
    """PIDs of other VibePause.exe processes (installed builds only)."""
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return []
    from ctypes import wintypes
    exe_name = os.path.basename(sys.executable).lower()

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
                    ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
                    ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

    pids = []
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
        kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        kernel32.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PROCESSENTRY32W)]
        kernel32.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PROCESSENTRY32W)]
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        snap = kernel32.CreateToolhelp32Snapshot(0x2, 0)   # TH32CS_SNAPPROCESS
        if snap in (None, 0, ctypes.c_void_p(-1).value):
            return []
        try:
            entry = PROCESSENTRY32W()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            ok = kernel32.Process32FirstW(snap, ctypes.byref(entry))
            while ok:
                if entry.szExeFile.lower() == exe_name and entry.th32ProcessID != os.getpid():
                    pids.append(int(entry.th32ProcessID))
                ok = kernel32.Process32NextW(snap, ctypes.byref(entry))
        finally:
            kernel32.CloseHandle(snap)
    except Exception:
        pass
    return pids

def terminate_process(pid):
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        kernel32.WaitForSingleObject.restype = ctypes.c_uint32
        kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel32.OpenProcess(0x0001 | 0x00100000, False, pid)   # TERMINATE | SYNCHRONIZE
        if handle:
            kernel32.TerminateProcess(handle, 0)
            kernel32.WaitForSingleObject(handle, 3000)
            kernel32.CloseHandle(handle)
    except Exception:
        pass

def close_running_instance(timeout=6.0):
    """Close the other VibePause and take over as the single instance.

    Asks it to exit cleanly first (so it removes its tray icon and saves
    settings). If that does not work within the timeout, for example an older
    version that does not listen for the request, it is ended forcefully.
    Returns True once this process owns the instance mutex.
    """
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenEventW.restype = ctypes.c_void_p
        kernel32.OpenEventW.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p]
        kernel32.SetEvent.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        event = kernel32.OpenEventW(0x0002, False, QUIT_EVENT_NAME)   # EVENT_MODIFY_STATE
        if event:
            kernel32.SetEvent(event)
            kernel32.CloseHandle(event)
    except Exception:
        pass

    def wait_for_release(seconds):
        deadline = time.time() + seconds
        while time.time() < deadline:
            if not already_running():      # also acquires the mutex for us
                return True
            time.sleep(0.2)
        return False

    if wait_for_release(timeout):
        return True
    for pid in find_other_instance_pids():
        terminate_process(pid)
    return wait_for_release(4.0)

def message_box(text, flags):
    # MB_SETFOREGROUND | MB_TOPMOST so the prompt is not hidden behind other windows
    return ctypes.windll.user32.MessageBoxW(None, text, APP_NAME, flags | 0x10000 | 0x40000)

def handle_existing_instance():
    """Called when another copy is running. Returns True if we should carry on starting up."""
    if "--startup" in sys.argv:
        return False   # launched by Windows at sign-in while already running: nothing to ask
    answer = message_box(
        "VibePause is already running.\n\n"
        "Click OK to close the running copy and open a new one,\n"
        "or Cancel to leave it as it is.",
        0x1 | 0x20)    # MB_OKCANCEL | MB_ICONQUESTION
    if answer != 1:    # IDOK
        return False
    if close_running_instance():
        return True
    message_box(
        "VibePause could not close the running copy.\n\n"
        "Right-click its tray icon, choose Exit VibePause, then try again.",
        0x0 | 0x30)    # MB_OK | MB_ICONWARNING
    return False

if __name__ == "__main__":
    setup_win32()
    set_windows_app_id()
    if already_running() and not handle_existing_instance():
        sys.exit(0)
    root = tk.Tk()
    App(root)
    root.mainloop()